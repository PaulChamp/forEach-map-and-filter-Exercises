// $ url https://api.nytimes.com/svc/search/v2/articlesearch.json?q=election&api-key=yourkey
$("button").on("click", function(e){
    e.preventDefault();
})



//key:
//mzwyBNtV4DEIALemuvoXOIhMzWSPXZq5


//secret:
//GIRTfYHE3JAkmzkd